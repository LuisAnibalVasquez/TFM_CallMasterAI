import Link from "next/link"
import { PhoneCall } from "lucide-react"
import { Button } from "@/components/ui/button"

const NAV_LINKS = [
  { href: "#features", label: "Características" },
  { href: "#how-it-works", label: "Cómo funciona" },
  { href: "#trust", label: "Confianza" },
  { href: "#pricing", label: "Precios" },
]

export function Navbar() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-card/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link
          href="/"
          className="flex items-center gap-2.5"
          aria-label="Call Master AI — Inicio"
        >
          <span
            className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-foreground"
            aria-hidden="true"
          >
            <PhoneCall className="h-4 w-4 text-background" strokeWidth={2.25} />
            <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-accent ring-2 ring-card animate-pulse-soft" />
          </span>
          <div className="flex flex-col leading-none">
            <span className="text-sm font-semibold tracking-tight text-foreground">
              Call Master <span className="text-primary">AI</span>
            </span>
            <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
              Voice Orchestration
            </span>
          </div>
        </Link>

        <nav
          aria-label="Navegación principal"
          className="hidden items-center gap-1 md:flex"
        >
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Button
            asChild
            variant="ghost"
            size="sm"
            className="text-muted-foreground hover:bg-secondary hover:text-foreground"
          >
            <Link href="/login">Log In</Link>
          </Button>
          <Button
            asChild
            size="sm"
            className="bg-foreground text-background shadow-soft hover:bg-foreground/90"
          >
            <Link href="/signup">Empezar ahora</Link>
          </Button>
        </div>
      </div>
    </header>
  )
}
